package com.example.tiktaktok;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

import static com.example.tiktaktok.LogginSignupActivity.myRef;

public class scoresHistoryActivity extends AppCompatActivity {
    ArrayList <Player> playersArr ;
    ListView lv_players;
    PlayerAdapter playerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scores_history);
        playersArr = new ArrayList<>();
        lv_players = (ListView)findViewById(R.id.lv_players);

        Query q = myRef.child("Users Table").orderByKey();

        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                for (DataSnapshot dst : snapshot.getChildren()) {
                    Player player = dst.getValue(Player.class);
                    playersArr.add(player);
                }
                bubbleSort(playersArr);

                //adapter
                if(playersArr.size()!=0) {
                    playerAdapter = new PlayerAdapter(scoresHistoryActivity.this, 0, 0, playersArr);
                    lv_players.setAdapter(playerAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });




    }
    

    public void bubbleSort(ArrayList<Player> array) {
        boolean sorted = false;
        Player temp;
        while (!sorted) {
            sorted = true;
            for (int i = 0; i < array.size() - 1; i++) {
                if (array.get(i).getScore() < array.get(i+1).getScore()) {
                    temp = array.get(i);
                    array.set(i,array.get(i+1));
                    array.set(i+1,temp);
                    sorted = false;
                }
            }
        }
    }
}